#include <QCoreApplication>
#include <iostream>
#include <QBuffer>
#include <QFile>
#include <QDebug>
#include <QtNetwork/QHostInfo>
#include "blockingclient.h"

using namespace std;

void write(QString fileName){
    QFile mFile(fileName);

    if(!mFile.open(QFile::WriteOnly | QFile::Text))
    {
        qDebug() << "Could not open file for writting!" ;
        return;
    }

    QTextStream out(&mFile);
    out << "hello world!";

    mFile.flush();
    mFile.close();
}


void read(QString fileName){
    QFile mFile(fileName);

    if(!mFile.open(QFile::ReadOnly | QFile::Text))
    {
        qDebug() << "Could not open file for reading!" ;
        return;
    }

    QTextStream in(&mFile);

    QString mText = in.readAll();

    qDebug() << mText ;

    mFile.close();
}



int main(int argc, char *argv[])
{
    QCoreApplication a(argc, argv);

//    QString fileName = "C:/Users/GiangPT/Documents/SourceCodes/QT/QtConsoleApp/test.txt";

//    write(fileName);
//    read(fileName);

//    QBuffer buffer;
//    char ch;

//    buffer.open(QBuffer::ReadWrite);
//    buffer.write("Qt rocks!");
//    buffer.seek(0);
//    buffer.getChar(&ch);  // ch == 'Q'
//    buffer.getChar(&ch);  // ch == 't'"qt-project.org", SLOT(printResults(QHostInfo))
//    buffer.getChar(&ch);  // ch == ' '
//    buffer.getChar(&ch);  // ch == 'r'

    BlockingClient client;
    client.show();

    printf("giang.pt1 hello world!\n");

    cout<<"hello world"<<endl;

    return a.exec();
}
