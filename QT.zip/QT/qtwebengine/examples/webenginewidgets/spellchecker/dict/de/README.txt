This is dummy german dictionary which knows only following words:

* ich
* du
* er
* sie
* es
* wir
* ihr
* sie
* Sie
* liebe
* liebst
* liebt
* lieben
* liebt
* qt

Also each of words above can start with 'q' for example
* qich
