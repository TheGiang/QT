#include "mynetaccessmanager.h"

#include <QtNetwork>

MyNetAccessManager::MyNetAccessManager(QObject *parent) :
    QObject(parent)
{
}

void MyNetAccessManager::doConnect()
{
    QNetworkAccessManager *manager = new QNetworkAccessManager(this);
    connect(manager, &QNetworkAccessManager::finished,
            this, &MyNetAccessManager::replyFinished);

    QNetworkRequest request;
    request.setUrl(QUrl("http://qt-project.org"));
    request.setRawHeader("User-Agent", "MyOwnBrowser 1.0");


    QNetworkReply *reply = manager->get(request);
    connect(reply, &QIODevice::readyRead, this, &MyNetAccessManager::slotReadyRead);
    connect(reply, &QNetworkReply::errorOccurred,
            this, &MyNetAccessManager::slotError);
    connect(reply, &QNetworkReply::sslErrors,
            this, &MyNetAccessManager::slotSslErrors);
    connect(reply, &QNetworkReply::metaDataChanged,
            this, &MyNetAccessManager::metaDataChanged);
    connect(reply, &QNetworkReply::finished,
            this, &MyNetAccessManager::finished);
    connect(reply, &QNetworkReply::uploadProgress,
            this, &MyNetAccessManager::uploadProgress);
    connect(reply, &QNetworkReply::downloadProgress,
            this, &MyNetAccessManager::downloadProgress);
}

void MyNetAccessManager::replyFinished()
{
    qDebug() << "replyFinished...";
}

void MyNetAccessManager::slotReadyRead()
{
    qDebug() << "slotReadyRead ...";
}

void MyNetAccessManager::slotError()
{
    qDebug() << "slotError ...";
}

void MyNetAccessManager::slotSslErrors()
{
    qDebug() << "slotSslErrors ...";
}

void MyNetAccessManager::metaDataChanged()
{
    qDebug() << "metaDataChanged ...";
}

void MyNetAccessManager::finished()
{
    qDebug() << "finished ...";
}

void MyNetAccessManager::uploadProgress(qint64 bytesSent, qint64 bytesTotal)
{
    QStringList words;
    words  << "bytesSent :"<< QString::number(bytesSent) << "  ---  bytesTotal :" << QString::number(bytesTotal);
    QString testString;

    for (auto it = words.constBegin(); it != words.constEnd(); ++it)
    {
        testString = testString % *it % " ";
    }

    qDebug() << "uploadProgress  ... " << testString;
}

void MyNetAccessManager::downloadProgress(qint64 bytesReceived, qint64 bytesTotal)
{
    QStringList words;
    words  << "bytesReceived :"<< QString::number(bytesReceived) << " ---  bytesTotal :" << QString::number(bytesTotal);
    QString testString;

    for (auto it = words.constBegin(); it != words.constEnd(); ++it)
    {
        testString = testString % *it % " ";
    }

    qDebug() << "downloadProgress  ... " << testString;
}
