#ifndef MYNETACCESSMANAGER_H
#define MYNETACCESSMANAGER_H

#include <QObject>
#include <QTcpSocket>
#include <QAbstractSocket>
#include <QDebug>
#include <QtNetwork>

class MyNetAccessManager : public QObject
{
    Q_OBJECT
public:
    explicit MyNetAccessManager(QObject *parent = 0);

    void doConnect();

signals:

public slots:

    void replyFinished();

    void slotReadyRead();
    void slotError();
    void slotSslErrors();

    void metaDataChanged();
    void finished();

    void uploadProgress(qint64 bytesSent, qint64 bytesTotal);
    void downloadProgress(qint64 bytesReceived, qint64 bytesTotal);

private:
    QNetworkAccessManager *manager;

};

#endif // MYNETACCESSMANAGER_H
