#ifndef MYNETREQUEST_H
#define MYNETREQUEST_H

#include <QObject>
#include <QTcpSocket>
#include <QAbstractSocket>
#include <QDebug>
#include <QtNetwork>

class MyNetRequest : public QObject
{
    Q_OBJECT
public:
    explicit MyNetRequest(QObject *parent = 0);

    void doConnect();

signals:

public slots:

    void slotReadyRead();
    void slotError();
    void slotSslErrors();

private:

};

#endif // MYNETREQUEST_H
