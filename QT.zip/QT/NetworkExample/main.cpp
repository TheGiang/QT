#include <QCoreApplication>
#include <QtNetwork>
#include "mynetaccessmanager.h"


int main(int argc, char *argv[])
{
    QCoreApplication a(argc, argv);

    MyNetAccessManager s;
    s.doConnect();

    return a.exec();
}
