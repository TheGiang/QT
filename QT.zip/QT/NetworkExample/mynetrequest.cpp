#include "mynetrequest.h"

#include <QtNetwork>

MyNetRequest::MyNetRequest(QObject *parent)
    : QObject{parent}
{

}

void MyNetRequest::doConnect()
{

    QNetworkRequest request;
    request.setUrl(QUrl("http://qt-project.org"));
    request.setRawHeader("User-Agent", "MyOwnBrowser 1.0");

    QNetworkReply *reply = manager->get(request);
    connect(reply, &QIODevice::readyRead, this, &MyClass::slotReadyRead);
    connect(reply, &QNetworkReply::errorOccurred,
            this, &MyClass::slotError);
    connect(reply, &QNetworkReply::sslErrors,
            this, &MyClass::slotSslErrors);
}

void MyNetRequest::slotReadyRead()
{
    qDebug() << "slotReadyRead ...";
}

void MyNetRequest::slotError()
{
    qDebug() << "slotError ...";
}

void MyNetRequest::slotSslErrors()
{
    qDebug() << "slotSslErrors ...";
}
