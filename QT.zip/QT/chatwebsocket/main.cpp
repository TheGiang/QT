#include "chatserver.h"

#include <QApplication>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    ChatServer server(1234);
    return a.exec();
}
